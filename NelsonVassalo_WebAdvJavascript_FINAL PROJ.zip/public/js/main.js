/**
 * Created by nelsonvassalo on 11/12/16.
 */
var app = app || {};

app.main = (function() {
    var socket;

    var socketSetup = function(callback) {
        socket = io.connect();


        socket.on("result", function (data) {
           $('.answers').append('<div class="answer"><img src="' + data + '" /></div>');
            if ($('.answer').length <= 1) {
                $('body img').hide(0).delay(100).show(1000);
            }else {
                $('.answer:last-child').hide(0).show(1000);
            }
            $('.questions').animate({'opacity': 0.1} , 150);
        });

        socket.on("load", function (data) {
           data.forEach(function(index) {
               $(body).append('<img src="' + data[index] + '" />')
           })
        });


        callback();
    };

    eventAttach = function() {
        $('#message').keypress(function(e) {
            if (e.keyCode == 13) {
                socket.emit('msg-to-server', $('#message').val());
                setTimeout( function() {
                    $('#second').css("transform", "translateX(102%)");
                    $('#third').css("transform", "translateX(204%)");

                    $('#message').val("").blur();
                }, 75);
            }
        });

        $('#send').on('mousedown', function(e) {
            socket.emit('msg-to-server', $('#message').val());
            setTimeout( function() {
                $('#second').css("transform", "translateX(102%)");
                $('#third').css("transform", "translateX(204%)");

                $('#message').val("").blur();
            }, 75);
        });

        $('.questions').on('mouseover', function () {
            var $this = $(this);
            if ($this.css("opacity") <= 0.15) {
                $(this).animate({"opacity": 1}, 150);
            }
        });

        $('.question:not(.headline)').on('mousedown', function (e) {
            $('#second').css('transform', 'translateX(0)');
        });

        $('.next').on('click', function (e) {
            $('#third').css('transform', 'translateX(0)');
            setTimeout( function() {
                $('textarea').focus();
            }, 1400);
        })
    };

    var init = function() {
        socketSetup(eventAttach);
    };

    return {
        init: init
    }
})();

window.addEventListener('DOMContentLoaded', app.main.init);