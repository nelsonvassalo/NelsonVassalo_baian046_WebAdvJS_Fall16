/**
 * Created by nelsonvassalo on 03/12/16.
 */
var fs = require('fs');
var express = require('express');
var app = express();
var PORT = 5000;
var gm = require("gm").subClass({imageMagick: true});



app.use('/', express.static(__dirname + '/public'));


var server = require('http').createServer(app);
var io = require('socket.io')(server);
var dir = __dirname + '/public/imgs';

server.listen(PORT, function() {
   console.log('Server listening at port ' + PORT);
});

var randomNr = function(min,max) {
    return Math.random() * (max - min) + min;
}

var randomDir = function() {
    var directions = [
        "Center",
        "North",
        "NorthWest"
    ];
  return directions[Math.floor(Math.random() * directions.length)]
};


var addNewlines = function(str){
    var result = '';
    while (str.length > 0) {
        result += str.substring(0, 17) + '-\n';
        str = str.substring(17);
    }
    return result;
};

var randomBack = function() {
  return dir + "/base/example-" + Math.round(randomNr(1,4)) +".png"
};

var randomFont = function() {
    var fonts = [
        __dirname + '/public/fonts/AkzidenzGrotesk-BoldExtended.otf',
        __dirname + '/public/fonts/AkzidenzGrotesk-BoldCond.otf',
        __dirname + '/public/fonts/AkzidenzGrotesk-Super.otf'
    ];
    return fonts[Math.round(randomNr(-0.5,fonts.length-1))];
};


var drawImage = function(socket, text) {
    var star = dir + "/base/star.png";
    var str = addNewlines(text);
    console.log(addNewlines(text));
    var lowered = socket.toLowerCase();
    var uppered = str.toUpperCase();
    console.log("socket if id" + lowered +'\n');
    gm(randomBack())
        .fill("#FFF")
        .fontSize(randomNr(70,110))
        .gravity(randomDir())
        .font(randomFont())
        .drawText(randomNr(10,60), randomNr(10,60), "EUROPE,\n" + uppered)

        .swirl(randomNr(-45,45))
        .write(dir + '/' +  lowered + '.png', function (err) {
            if (err) console.log(arguments);
            console.log("drawn\n" + lowered + "path: " + dir + '/' + lowered +'.png');
            io.sockets.emit('result', 'imgs/' + lowered +'.png');

        });
};

io.on('connection', function(socket){

    console.log( socket.id + "connected");


    io.sockets.emit('cid', socket.id);

    socket.on('load', function (data) {
        loadInitialImgs(dir, function() {
            io.socket.emit('load');
        })
    });
    //
    // client.on('event', function(data){});
    // client.on('disconnect', function(){});


    socket.on("msg-to-server", function(data) {
        io.sockets.emit('msg-to-clients', {
            msg: "loading"
        });
        drawImage(socket.id, data);
    });
});
//
// var loadInitialImgs = function(dir, callback) {
//     var fileType = '.jpg',
//         files = [], i;
//     fs.readdir(imageDir, function (err, list) {
//         for(i=0; i<list.length; i++) {
//             if(path.extname(list[i]) === fileType) {
//                 files.push(list[i]); //store the file name into the array files
//             }
//         }
//         callback(err, files);
//     });
// };
//
// loadInitialImgs(dir, function (err, files) {
//     files.forEach(function (index) {
//         console.log(files[index]);
//     })
// });


